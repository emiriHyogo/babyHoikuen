

/* =================
  03: カルーセルスライダー
 ================= */

$(document).ready(function(){
	$('.flexslider').flexslider({
		animation: "slide",
		controlNav: false,
		prevText: "",
		nextText: "",
	})
});