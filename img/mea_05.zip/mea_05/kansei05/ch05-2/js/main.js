$(document).ready(function(){



/* =================
  ヘッダー追従
 ================= */
  $(window).on('scroll', function(){
    if($(this).scrollTop() > 50){
      $('.globalHeader').addClass('fixed');
    } else {
      $('.globalHeader').removeClass('fixed');
    }
  })


/* =================
   テキスト色変更
 ================= */

// CSSのみで対応



/* =================
   画像反転／ボタン表示
 ================= */

// CSSのみで対応



/* =================
   お気に入りボタン  
 ================= */

  $('.favorite_btn').on('click', function(e){
    e.preventDefault();
    $(this).toggleClass('select');
  })


/* =================
   タブ切り替え
 ================= */
 
  $('#tabNav li a').on('click', function(e){
	e.preventDefault();
	
	var containerName = $(this).attr('href').replace('#', '');
	$('#tabContainer .container').removeClass('show');
	$('#tabContainer .' + containerName).addClass('show');
	
	$(this).parent().siblings().removeClass('select');
	$(this).parent().addClass('select');
  })




/* =================
  サイズ選択
 ================= */

  $('.sizeSelect ul li a').on('click', function(e){
	  e.preventDefault();
	  
	  var btn = $(this).parent();
	  btn.siblings().removeClass('select');
	  btn.addClass('select');
	  
	  if(btn.hasClass('empty')){
		  $('.sizeSelect').next().removeClass('hidden');
	  } else {
		  $('.sizeSelect').next().addClass('hidden');
	  }
  })

/* =================
   カートに入れるボタン
 ================= */
 
   $('#addCartButton').on('click', function(e){
	   if($(this).attr('href') === '#'){
		   e.preventDefault();
		   
		   $(this)
		   .addClass('ghost')
		   .text('カートの中身を見る')
		   .attr('href', 'cart.html');
		   
	   }
	   
   })
 



/* =================
   画像反転／ボタン表示
 ================= */




/* =================
  サムネイル選択で画像変更
 ================= */




/* =================
   合計金額が変わる
 ================= */




/* =================
   削除するボタン
 ================= */




/* =================
   カートの中身がない時、ボタンをグレーアウト
 ================= */




/* =================
   確定時、モーダルを表示する
 ================= */



/* =================
   サイズがない時アラートを表示
 ================= */





/* =================
  ハンバーガーメニュー
 ================= */

});